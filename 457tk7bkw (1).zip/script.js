function showTime() {
  const timeElement = document.getElementById('currentTime');
  if (timeElement) timeElement.textContent = new Date().toUTCString();
}

function scheduleClockUpdate() {
  showTime();
  setTimeout(scheduleClockUpdate, 1000);
}

scheduleClockUpdate();

function escapeSourceHtml(value) {
  return String(value || '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

function downloadTextFile(fileName, content, mimeType) {
  const blob = new Blob([content], { type: mimeType });
  const link = document.createElement('a');
  const url = URL.createObjectURL(blob);
  link.href = url;
  link.download = fileName;
  document.body.appendChild(link);
  link.click();
  link.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

function exportActiveChat(format) {
  let session = typeof window.getActiveSession === 'function' ? window.getActiveSession() : null;
  if (!session) {
    try {
      const sessions = JSON.parse(localStorage.getItem('vdl_chat_sessions') || '[]');
      session = sessions.find(item => item.id === localStorage.getItem('vdl_active_session_id')) || sessions[0];
    } catch (_) {}
  }
  if (!session || !session.messages || session.messages.length === 0) {
    if (typeof window.showToast === 'function') window.showToast('There is no chat history to export.', '⚠️');
    return;
  }

  const title = session.title || 'Chat conversation';
  const body = session.messages.map(message => {
    const speaker = message.role === 'user' ? 'You' : 'Vishal Digital Lab AI';
    const time = new Date(message.timestamp || session.createdAt || Date.now()).toLocaleString();
    return format === 'md'
      ? `## ${speaker} · ${time}\n\n${message.content || ''}`
      : `[${time}] ${speaker}:\n${message.content || ''}`;
  }).join(format === 'md' ? '\n\n---\n\n' : '\n\n');

  const content = format === 'md' ? `# ${title}\n\n${body}\n` : `${title}\n${'='.repeat(title.length)}\n\n${body}\n`;
  const safeName = title.replace(/[^a-z0-9-_]+/gi, '_').slice(0, 50) || 'chat';
  downloadTextFile(`${safeName}.${format}`, content, format === 'md' ? 'text/markdown;charset=utf-8' : 'text/plain;charset=utf-8');
}

function parseGoogleResults(htmlText) {
  const doc = new DOMParser().parseFromString(htmlText, 'text/html');
  const results = [];
  const seen = new Set();

  doc.querySelectorAll('h3').forEach(heading => {
    const anchor = heading.closest('a[href]');
    if (!anchor) return;

    let url = anchor.getAttribute('href') || '';
    try {
      const parsedUrl = new URL(url, 'https://www.google.com');
      if (parsedUrl.pathname === '/url') url = parsedUrl.searchParams.get('q') || parsedUrl.searchParams.get('url') || url;
      else if (parsedUrl.hostname === 'www.google.com' || parsedUrl.hostname === 'google.com') return;
    } catch (_) {
      return;
    }
    if (!/^https?:\/\//i.test(url) || seen.has(url)) return;

    const resultBlock = heading.closest('.MjjYud, .g') || heading.parentElement?.parentElement || heading.parentElement;
    const snippetNode = resultBlock?.querySelector('.VwiC3b, [data-snf], .IsZvec, .aCOpRe');
    seen.add(url);
    results.push({
      title: heading.textContent.trim(),
      url,
      snippet: snippetNode?.textContent.trim() || ''
    });
  });
  return results;
}

function renderGoogleResults(results, pane) {
  pane.replaceChildren();
  if (!results.length) {
    pane.innerHTML = '<p class="text-xs text-slate-400 p-3">No organic results were found in the returned page. Google may have changed its markup or served a consent/CAPTCHA page.</p>';
    return;
  }

  results.forEach(result => {
    const card = document.createElement('article');
    card.className = 'p-3 rounded-xl bg-brand-surfaceHover border border-brand-border';
    const link = document.createElement('a');
    link.className = 'text-sm font-semibold text-cyan-300 hover:underline break-words';
    link.href = result.url;
    link.target = '_blank';
    link.rel = 'noopener noreferrer';
    link.textContent = result.title;
    const urlText = document.createElement('p');
    urlText.className = 'text-[10px] text-emerald-400 break-all mt-1';
    urlText.textContent = result.url;
    const snippet = document.createElement('p');
    snippet.className = 'text-xs text-slate-300 mt-2 leading-relaxed';
    snippet.textContent = result.snippet || 'No snippet was available.';
    card.append(link, urlText, snippet);
    pane.appendChild(card);
  });
}

function setupGoogleSourceUtility() {
  const modal = document.getElementById('googleSourceModal');
  const openBtn = document.getElementById('openGoogleSourceBtn');
  const closeBtn = document.getElementById('closeGoogleSourceBtn');
  const form = document.getElementById('googleSourceForm');
  const queryInput = document.getElementById('googleSourceQuery');
  const searchBtn = document.getElementById('googleSourceSearchBtn');
  const notice = document.getElementById('googleSourceNotice');
  const resultsPane = document.getElementById('googleResultsPane');
  const rawPane = document.getElementById('googleRawPane');
  const rawCode = document.getElementById('googleRawCode');
  const renderedToggle = document.getElementById('googleRenderedToggle');
  const rawToggle = document.getElementById('googleRawToggle');
  if (!modal || !openBtn || !form) return;

  const closeModal = () => {
    modal.classList.add('hidden');
    modal.classList.remove('flex');
  };
  openBtn.addEventListener('click', () => {
    modal.classList.remove('hidden');
    modal.classList.add('flex');
    if (typeof window.closeSidebar === 'function') window.closeSidebar();
    queryInput.focus();
  });
  closeBtn.addEventListener('click', closeModal);
  modal.addEventListener('click', event => { if (event.target === modal) closeModal(); });

  renderedToggle.addEventListener('click', () => {
    resultsPane.classList.remove('hidden');
    rawPane.classList.add('hidden');
  });
  rawToggle.addEventListener('click', () => {
    resultsPane.classList.add('hidden');
    rawPane.classList.remove('hidden');
  });

  form.addEventListener('submit', async event => {
    event.preventDefault();
    const input = queryInput.value.trim();
    if (!input) {
      notice.textContent = 'Enter a search query or Google Search URL first.';
      notice.className = 'mx-3 mt-3 p-3 rounded-xl border border-amber-500/30 bg-amber-950/30 text-amber-200 text-xs';
      return;
    }

    const searchUrl = /^https?:\/\//i.test(input)
      ? input
      : `https://www.google.com/search?q=${encodeURIComponent(input)}`;
    searchBtn.disabled = true;
    searchBtn.classList.add('opacity-50', 'cursor-not-allowed');
    searchBtn.textContent = 'Fetching…';
    notice.classList.add('hidden');
    try {
      const response = await fetch(searchUrl, {
        method: 'GET',
        headers: { Accept: 'text/html,application/xhtml+xml' }
      });
      if (!response.ok) throw new Error(`Google returned HTTP ${response.status}.`);
      const htmlText = await response.text();
      rawCode.textContent = htmlText;
      if (window.hljs) {
        rawCode.removeAttribute('data-highlighted');
        rawCode.classList.remove('hljs');
        window.hljs.highlightElement(rawCode);
      }

      if (/Our systems have detected unusual traffic|not a robot|unusual traffic/i.test(htmlText)) {
        notice.textContent = 'Google returned a CAPTCHA or unusual-traffic page. Try later, or use a permitted backend proxy or browser-extension mode.';
        notice.className = 'mx-3 mt-3 p-3 rounded-xl border border-amber-500/30 bg-amber-950/30 text-amber-200 text-xs';
        notice.classList.remove('hidden');
      } else {
        notice.textContent = `Source loaded (${htmlText.length.toLocaleString()} characters). Browser CORS or Google markup can limit extraction.`;
        notice.className = 'mx-3 mt-3 p-3 rounded-xl border border-emerald-500/30 bg-emerald-950/30 text-emerald-200 text-xs';
        notice.classList.remove('hidden');
      }
      renderGoogleResults(parseGoogleResults(htmlText), resultsPane);
      resultsPane.classList.remove('hidden');
      rawPane.classList.add('hidden');
    } catch (error) {
      notice.textContent = `Could not fetch Google Search from this browser (${error.message || 'network/CORS restriction'}). Google commonly blocks client-side cross-origin requests. Use a trusted backend proxy or a Chrome extension with appropriate host permissions; do not send private queries through an untrusted proxy.`;
      notice.className = 'mx-3 mt-3 p-3 rounded-xl border border-rose-500/30 bg-rose-950/30 text-rose-200 text-xs';
      notice.classList.remove('hidden');
      resultsPane.replaceChildren();
      rawCode.textContent = '';
    } finally {
      searchBtn.disabled = false;
      searchBtn.classList.remove('opacity-50', 'cursor-not-allowed');
      searchBtn.textContent = 'Search';
    }
  });
}

function parsePresentationText(rawText) {
  const lines = String(rawText || '').split(/\r?\n/).map(line => line.trim()).filter(Boolean);
  if (!lines.length) return { title: 'Presentation', sections: [] };

  const headingPattern = /^(?:#{1,3}\s+|slide\s*:\s*|slide\s+\d+\s*[:.-]?\s*)/i;
  const headedSections = [];
  let current = null;
  lines.forEach(line => {
    if (headingPattern.test(line)) {
      if (current) headedSections.push(current);
      current = { title: line.replace(headingPattern, '').trim() || `Slide ${headedSections.length + 1}`, lines: [] };
    } else if (current) {
      current.lines.push(line);
    }
  });
  if (current) headedSections.push(current);
  if (headedSections.length) {
    const firstTitle = headedSections[0].title || 'Presentation';
    return {
      title: firstTitle,
      sections: headedSections.map(section => ({
        title: section.title,
        body: section.lines.map(line => line.replace(/^\s*(?:[-*•]|\d+[.)])\s*/, '')).filter(Boolean)
      }))
    };
  }

  const paragraphs = String(rawText).split(/\n\s*\n+/).map(part => part.trim()).filter(Boolean);
  const firstParagraphLines = (paragraphs[0] || '').split(/\r?\n/).map(line => line.trim()).filter(Boolean);
  const firstNonBullet = firstParagraphLines.find(line => !/^(?:[-*•]|\d+[.)])\s+/.test(line));
  const title = (firstNonBullet || firstParagraphLines[0] || 'Presentation').replace(/^#+\s*/, '').slice(0, 90);
  let blocks = paragraphs.slice(1).map((paragraph, index) => {
    const blockLines = paragraph.split(/\r?\n/).map(line => line.trim()).filter(Boolean);
    const hasHeading = blockLines.length > 1 && !/^(?:[-*•]|\d+[.)])\s+/.test(blockLines[0]);
    return {
      title: hasHeading ? blockLines[0].replace(/^#+\s*/, '') : `Key Ideas ${index + 1}`,
      body: (hasHeading ? blockLines.slice(1) : blockLines).map(line => line.replace(/^\s*(?:[-*•]|\d+[.)])\s*/, '')).filter(Boolean)
    };
  });

  if (!blocks.length) {
    const bullets = firstParagraphLines.filter(line => /^(?:[-*•]|\d+[.)])\s+/.test(line));
    const bodyLines = bullets.length ? bullets : firstParagraphLines.filter(line => line !== firstNonBullet);
    for (let index = 0; index < bodyLines.length; index += 5) {
      blocks.push({ title: `Key Ideas ${blocks.length + 1}`, body: bodyLines.slice(index, index + 5).map(line => line.replace(/^\s*(?:[-*•]|\d+[.)])\s*/, '')) });
    }
  }
  return { title, sections: blocks };
}

async function generateModernPresentation(topicOrText) {
  try {
    const Constructor = typeof PptxGenJS !== 'undefined' ? PptxGenJS : window.PptxGenJS;
    if (typeof Constructor !== 'function') throw new Error('PptxGenJS is unavailable.');
    const pptx = typeof PptxGenJS !== 'undefined' ? new PptxGenJS() : new window.PptxGenJS();
    pptx.defineLayout({ name: 'LAYOUT_16_9', width: 13.333, height: 7.5 });
    pptx.layout = 'LAYOUT_16_9';
    pptx.author = 'Vishal Digital Lab AI';
    pptx.subject = 'AI generated presentation';
    pptx.title = 'Vishal Digital Lab AI Presentation';
    pptx.theme = { headFontFace: 'Aptos Display', bodyFontFace: 'Aptos', lang: 'en-US' };

    const parsed = parsePresentationText(topicOrText);
    const cover = pptx.addSlide();
    cover.background = { color: '0F172A' };
    cover.addShape(pptx.ShapeType.roundRect, { x: 5.43, y: 1.25, w: 2.45, h: 0.38, rectRadius: 0.08, line: { color: '6366F1', transparency: 100 }, fill: { color: '1E293B' } });
    cover.addText('VISHAL DIGITAL LAB AI', { x: 5.52, y: 1.34, w: 2.27, h: 0.15, fontFace: 'Aptos', fontSize: 9, bold: true, charSpacing: 1.5, color: '38BDF8', align: 'center', margin: 0 });
    cover.addShape(pptx.ShapeType.rect, { x: 5.65, y: 2.05, w: 2.03, h: 0.06, line: { color: '6366F1', transparency: 100 }, fill: { color: '6366F1' } });
    cover.addText(parsed.title, { x: 1.0, y: 2.45, w: 11.33, h: 1.45, fontFace: 'Aptos Display', fontSize: 36, bold: true, color: 'FFFFFF', align: 'center', valign: 'mid', fit: 'shrink', margin: 0.08 });
    cover.addText('A concise, structured presentation', { x: 2.0, y: 4.1, w: 9.33, h: 0.45, fontFace: 'Aptos', fontSize: 18, color: '94A3B8', align: 'center', margin: 0 });
    cover.addText('Vishal Digital Lab AI', { x: 0.5, y: 6.95, w: 12.33, h: 0.2, fontSize: 9, color: '475569', align: 'center', margin: 0 });

    const sections = parsed.sections.length ? parsed.sections : [{ title: 'Key Takeaways', body: [parsed.title] }];
    sections.slice(0, 20).forEach((section, index) => {
      const slide = pptx.addSlide();
      slide.background = { color: '0F172A' };
      slide.addShape(pptx.ShapeType.rect, { x: 0.55, y: 0.56, w: 0.08, h: 0.62, line: { color: '6366F1', transparency: 100 }, fill: { color: '6366F1' } });
      slide.addText(section.title || `Key Ideas ${index + 1}`, { x: 0.82, y: 0.54, w: 11.9, h: 0.62, fontFace: 'Aptos Display', fontSize: 22, bold: true, color: 'FFFFFF', fit: 'shrink', margin: 0.02 });
      slide.addShape(pptx.ShapeType.rect, { x: 0.82, y: 1.27, w: 1.15, h: 0.045, line: { color: '38BDF8', transparency: 100 }, fill: { color: '38BDF8' } });
      slide.addShape(pptx.ShapeType.roundRect, { x: 0.68, y: 1.62, w: 11.95, h: 4.95, rectRadius: 0.08, line: { color: '1E293B', width: 1 }, fill: { color: '172033' } });
      const bodyLines = (section.body || []).length ? section.body : ['Add supporting details or examples for this section.'];
      const body = bodyLines.map(line => `•  ${line}`).join('\n');
      slide.addText(body, { x: 1.05, y: 1.95, w: 11.2, h: 4.35, fontFace: 'Aptos', fontSize: 15, color: 'E2E8F0', breakLine: false, valign: 'top', fit: 'shrink', lineSpacing: 28, paraSpaceAfterPt: 10, margin: 0.06 });
      slide.addText('Vishal Digital Lab AI', { x: 0.55, y: 7.0, w: 4.5, h: 0.18, fontFace: 'Aptos', fontSize: 9, color: '475569', margin: 0 });
      slide.addText(`${index + 2}`, { x: 12.1, y: 6.98, w: 0.65, h: 0.2, fontFace: 'Aptos', fontSize: 9, color: '475569', align: 'right', margin: 0 });
    });

    const fileName = `Presentation_${Date.now()}.pptx`;
    await pptx.writeFile({ fileName });
    const dataUri = await pptx.write({ outputType: 'datauristring' });
    if (typeof window.addFileToLibrary === 'function') {
      window.addFileToLibrary(fileName, 'ppt', dataUri, parsed.title);
    }
    if (typeof window.showToast === 'function') window.showToast('Modern presentation created and saved.', '📊');
    const toolModal = document.getElementById('aiToolModal');
    if (toolModal) toolModal.classList.add('hidden');
  } catch (error) {
    console.error('Error creating presentation slides:', error);
    if (typeof window.showToast === 'function') window.showToast(`Could not create presentation: ${error.message || 'unknown error'}`, '⚠️');
  }
}

window.addEventListener('DOMContentLoaded', () => {
  setupGoogleSourceUtility();

  const exportButton = document.getElementById('exportMarkdownBtn');
  if (exportButton) exportButton.addEventListener('click', () => exportActiveChat('md'));
  const exportTextButton = document.getElementById('exportTextBtn');
  if (exportTextButton) exportTextButton.addEventListener('click', () => exportActiveChat('txt'));

  // Keep the older session storage key readable while all new writes use the requested key.
  try {
    const savedSessions = localStorage.getItem('vdl_chat_sessions');
    if (!savedSessions && localStorage.getItem('vdl_ai_sessions')) {
      localStorage.setItem('vdl_chat_sessions', localStorage.getItem('vdl_ai_sessions'));
    }
  } catch (_) {}

  window.createNewChat = function() {
    if (typeof window.createNewSession === 'function') window.createNewSession();
  };
  window.loadSession = function(sessionId) {
    if (typeof window.switchSession === 'function') window.switchSession(sessionId);
  };
  window.saveCurrentMessage = function(role, content) {
    const session = typeof window.getActiveSession === 'function' ? window.getActiveSession() : null;
    if (!session) return;
    const timestamp = Date.now();
    session.messages = Array.isArray(session.messages) ? session.messages : [];
    session.messages.push({ role: role === 'user' ? 'user' : 'model', content: String(content || ''), timestamp });
    if (role === 'user' && session.messages.filter(message => message.role === 'user').length === 1) {
      session.title = String(content || 'New Conversation').trim().slice(0, 30) || 'New Conversation';
    }
    if (typeof window.saveSessionsToStorage === 'function') window.saveSessionsToStorage();
  };

  // The main app calls this global function from its presentation tool action.
  window.generatePresentationSlides = generateModernPresentation;
});
